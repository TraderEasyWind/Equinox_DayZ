modded class Clothing extends Clothing_Base
{
	protected int m_BagSound = 0;
	
	void Clothing()
	{
		RegisterNetSyncVariableInt("m_BagSound", -1, 1);
	}
	
	override void OnRPC(PlayerIdentity sender, int rpc_type,ParamsReadContext  ctx) 
	{
		super.OnRPC(sender, rpc_type, ctx);

		Param1<bool> p = new Param1<bool>(false);
					
		if (!ctx.Read(p))
			return;

		if (rpc_type == 3675309)
		{
			if (p.param1)
			{
				m_BagSound = 1;
			}
			else
			{
				m_BagSound = -1;
			}

			SetSynchDirty();
			GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(ResetSoundTrigger, 100, false);
		}
	}
	
	protected void ResetSoundTrigger()
	{
		m_BagSound = 0;
		SetSynchDirty();
	}
	
	override void OnVariablesSynchronized()
	{
		super.OnVariablesSynchronized();

		if (GetGame().IsMultiplayer() && GetGame().IsClient())
		{
			if (m_BagSound != 0)
			{
				PlayBagSound(Math.SignInt(m_BagSound) == 1);
				m_BagSound = 0;
			}
		}
	}
	
	protected void PlayBagSound(bool opening)
	{
		string soundName;

		if (opening)
			soundName = GetOpenSound();
		else
			soundName = GetCloseSound();
		
		if (soundName == "")
			return;
		
		EffectSound effect_sound;
		PlaySoundSet(effect_sound, soundName, false, false, false);
		effect_sound.SetSoundAutodestroy(true);
	}
	
	protected string GetOpenSound()
	{
		return "MassiveModZipper_Soundset";
	}
	
	protected string GetCloseSound()
	{
		return "MassiveModZipper_Soundset";
	}
}
modded class HuntingBag : Clothing 
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
};
modded class MassSurvivorBag: Clothing
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
};
class Massbag : MountainBag_ColorBase
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
};
modded class ChildBag_ColorBase extends Clothing 
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
};
modded class SmershBag extends Clothing
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingClickSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingClickSFX_Soundset";
	}
};
modded class AssaultBag_ColorBase extends Clothing 
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingClickSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingClickSFX_Soundset";
	}
};
modded class AliceBag_ColorBase extends Clothing 
{
	override protected string GetOpenSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
};
modded class AliceBag_ColorBase extends Clothing 
{
	override protected string GetOpenSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
};
modded class CourierBag : Clothing 
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
};
modded class ImprovisedBag : Clothing 
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
};
modded class MassImprovisedBag_Colorbase: Clothing
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
};
modded class LeatherSack_ColorBase extends Clothing
{
	override protected string GetOpenSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModRustlingSFX_Soundset";
	}
};
modded class MassRuckBagDesert
{
	override protected string GetOpenSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
};
modded class CoyoteBag_ColorBase: Clothing
{
	override protected string GetOpenSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
}
modded class TortillaBag: Clothing
{
	override protected string GetOpenSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
	
	override protected string GetCloseSound()
	{
		return "MassiveModHeavyMilitaryBagSFX_Soundset";
	}
}

