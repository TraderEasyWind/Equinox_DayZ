modded class mmg_gun_rack_base
{
	override float GetCostToUpkeep()
    {
		return 0.35;
    }
}
modded class mmg_lockable_gun_rack_base
{
	override float GetCostToUpkeep()
    {
		return 0.35;
    }
}