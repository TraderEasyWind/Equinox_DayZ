modded class mmg_gear_stand_base
{
	override float GetCostToUpkeep()
    {
        return 0.70;
    }
}