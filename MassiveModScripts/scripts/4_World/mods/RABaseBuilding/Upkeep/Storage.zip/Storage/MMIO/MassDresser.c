modded class MassDresser
{
	override float GetCostToUpkeep()
    {
        return 0.70;
    }	
}