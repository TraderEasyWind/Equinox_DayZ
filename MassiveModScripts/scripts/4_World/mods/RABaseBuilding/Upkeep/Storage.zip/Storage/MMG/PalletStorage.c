modded class mmg_palette_storage_base
{
	override float GetCostToUpkeep()
    {
        return 3.5;
    }
}