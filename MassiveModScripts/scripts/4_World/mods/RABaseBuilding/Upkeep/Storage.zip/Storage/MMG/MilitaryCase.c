modded class mmg_military_case_base
{
	override float GetCostToUpkeep()
    {
        return 2.8;
    }
}