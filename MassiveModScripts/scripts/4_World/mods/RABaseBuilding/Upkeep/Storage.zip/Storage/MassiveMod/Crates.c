modded class MassiveMod_WoodenCrateX2
{
	override float GetCostToUpkeep()
    {
        return 0.70;
    }
}
modded class MassiveMod_WoodenCrateX4
{
	override float GetCostToUpkeep()
    {
        return 1.4;
    }
}
modded class MassiveMod_WoodenCrateX8
{
	override float GetCostToUpkeep()
    {
        return 2.8;
    }
}