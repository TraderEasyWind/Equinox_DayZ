#ifdef RA_BaseBuilding_Scripts
modded class mmg_locker02_base
{
	override float GetCostToUpkeep()
    {
        return 2.8;
    }
}
modded class mmg_solo_locker_base
{
	override float GetCostToUpkeep()
    {
        return 1.4;
    }
}
modded class mmg_locker_base
{
	override float GetCostToUpkeep()
    {
        return 2.8;
    }
}
#endif