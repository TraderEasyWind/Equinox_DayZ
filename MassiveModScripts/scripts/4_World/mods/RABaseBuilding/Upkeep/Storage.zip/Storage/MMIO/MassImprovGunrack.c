modded class MassImprovGunRack
{	
	override float GetCostToUpkeep()
    {
        return 0.35;
    }	
}