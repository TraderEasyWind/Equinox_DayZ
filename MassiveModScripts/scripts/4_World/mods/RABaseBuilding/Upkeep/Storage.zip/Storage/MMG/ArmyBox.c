#ifdef RA_BaseBuilding_Scripts
modded class mmg_army_box_base
{
	override float GetCostToUpkeep()
    {
        return 1.4;
    }
}
#endif