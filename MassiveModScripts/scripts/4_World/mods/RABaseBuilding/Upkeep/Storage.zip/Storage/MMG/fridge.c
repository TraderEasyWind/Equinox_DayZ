modded class mmg_fridge_minsk_base
{
	override float GetCostToUpkeep()
    {
        return 0.70;
    }
}