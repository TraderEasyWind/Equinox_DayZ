class mmg_old_table_base: mmg_storage_placeable_base
{
	override float GetCostToUpkeep()
    {
        return 0.12;
    }
}