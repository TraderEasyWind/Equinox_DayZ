modded class mmg_gun_wall_base
{
	override float GetCostToUpkeep()
    {
		return 0.35;
    }
}