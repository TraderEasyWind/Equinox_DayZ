modded class Mosin9130
{
    override void EEOnCECreate()
    {
        if (!GetParent())
        {
            if (Math.RandomInt(1, 100) < 5)
            {
                TStringArray possibleObjects = 
                {
                    "MassSVT40"
                };
                string objectToSpawn = possibleObjects[Math.RandomInt(0, possibleObjects.Count())];
                EntityAI entity = EntityAI.Cast(GetGame().CreateObject(objectToSpawn, GetPosition(), false, true, true));
                entity.SetOrientation(GetOrientation());
                entity.EEOnCECreate();
                Print("[MassDEBUG] " + GetType() + " transformed into " + objectToSpawn);
                if (entity.IsInherited(MassSVT40))
                {
                    MassSVT40 svt40Entity = MassSVT40.Cast(entity);
                    svt40Entity.SpawnAttachmentsOnUpgrade();
                }
				Delete();
            }
        }
    }
	
	void SpawnAttachmentsOnUpgrade()
    {
        GameInventory m_Inventory = GetInventory();
        if (GetGame() &&  (GetGame().IsServer() || !GetGame().IsMultiplayer() ))
        {
            AddHealth("", "",9999);

            m_Inventory.CreateAttachment("PUScopeOptic");				
        }
    }
};
