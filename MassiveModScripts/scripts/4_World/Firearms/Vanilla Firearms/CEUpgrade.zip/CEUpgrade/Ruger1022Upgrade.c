//modded class Ruger1022_Base
//{
//	override void EEOnCECreate()
//    {
//        if (!GetParent())
//        {
//            if (Math.RandomInt(1, 100) < 5)
//            {
//                TStringArray possibleObjects = 
//                {
//                    "Mosin9130",
//					"Repeater",
//					"SSG82"
//                };
//                string objectToSpawn = possibleObjects[Math.RandomInt(0, possibleObjects.Count())];
//                EntityAI entity = EntityAI.Cast(GetGame().CreateObject(objectToSpawn, GetPosition(), false, true, true));
//                entity.SetOrientation(GetOrientation());
//                entity.EEOnCECreate();
//                Print("[MassDEBUG] " + GetType() + " transformed into " + objectToSpawn);
//                if (entity.IsInherited(Mosin9130))
//                {
//                    Mosin9130 mosin9130Entity = Mosin9130.Cast(entity);
//                    mosin9130entity.SpawnAttachmentsOnUpgrade();
//                }
//				Delete();
//            }
//        }
//    }
//};