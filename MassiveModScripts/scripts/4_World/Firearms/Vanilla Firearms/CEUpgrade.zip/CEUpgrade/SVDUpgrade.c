modded class SVD_Base : RifleBoltLock_Base
{
	override void EEOnCECreate()
    {
        if (!GetParent())
        {
            if (Math.RandomInt(1, 100) < 5)
            {
                TStringArray possibleObjects = 
                {
                    "Mass_SVU"
                };
                string objectToSpawn = possibleObjects[Math.RandomInt(0, possibleObjects.Count())];
                EntityAI entity = EntityAI.Cast(GetGame().CreateObject(objectToSpawn, GetPosition(), false, true, true));
                entity.SetOrientation(GetOrientation());
                entity.EEOnCECreate();
                Print("[MassDEBUG] " + GetType() + " transformed into " + objectToSpawn);
                if (entity.IsInherited(Mass_SVU))
                {
                    Mass_SVU mass_svuEntity = Mass_SVU.Cast(entity);
                    mass_svuEntity.SpawnAttachmentsOnUpgrade();
                }
				Delete();
            }
        }
    }
	
	void SpawnAttachmentsOnUpgrade()
    {
		ref TStringArray RandomOptics = 
		{
			"KazuarOptic",
			"Mass1P69",
			"Akol_AkMount_NoAttachment",
			"KashtanOptic",
			"PSO1Optic",
			"KobraOptic"
		}
		
        GameInventory m_Inventory = GetInventory();
        if (GetGame() &&  (GetGame().IsServer() || !GetGame().IsMultiplayer() ))
        {
            AddHealth("", "",9999);
            Magazine mag = SpawnAttachedMagazine("Mag_SVD_10Rnd", WeaponWithAmmoFlags.MAX_CAPACITY_MAG | WeaponWithAmmoFlags.CHAMBER);
            m_Inventory.CreateAttachment(RandomOptics.GetRandomElement());				
        }
    }
}