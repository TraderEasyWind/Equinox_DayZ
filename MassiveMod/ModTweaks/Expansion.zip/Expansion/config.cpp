class CfgPatches
{
	class MassiveMod_ModTweaks_Expansion
	{
		units[] = {""};
		weapons[] = {""};
		requiredVersion = 0.1;
		requiredAddons[] =
        {
            "DZ_Data",
			"DZ_Scripts"
        };
	};
};//meow