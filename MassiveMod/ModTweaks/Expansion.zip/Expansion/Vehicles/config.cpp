class CfgPatches
{
	class MassiveMod_ModTweaks_Expansion_Vehicles
	{
		units[] = {""};
		weapons[] = {""};
		requiredVersion = 0.1;
		requiredAddons[] =
        {
            "DZ_Data",
			"DZ_Scripts"
        };
	};
};//meow