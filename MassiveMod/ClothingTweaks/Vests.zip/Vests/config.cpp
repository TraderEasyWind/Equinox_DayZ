class CfgPatches
{
	class Spearhead_ClothingTweaks_Vests
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = 
		{
			"DZ_Data"
		};
		author = "Mass";
		name = "CMASIGAIMGHIDJFUASD";
	};
};